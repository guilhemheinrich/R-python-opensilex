library(testthat)
library(openshiny.outlier)

test_check("openshiny.outlier")
