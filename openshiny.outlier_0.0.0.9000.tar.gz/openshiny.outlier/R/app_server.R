
#' The application server-side
#' 
#' @param input,output,session Internal parameters for {shiny}. 
#'     DO NOT REMOVE.
#' @import shiny
#' @noRd
app_server <- function( input, output, session ) {
  authentification <- mod_authentification_server("auth")
  experiment <- mod_experiment_explorer_server("experiment", authentification, widget_options = list(multiple = FALSE))
  # so <- mod_scientific_object_explorer_server("so", authentification,  multiple = FALSE, options = list(experiment = experiment$selected))
  # event <- mod_event_explorer_server("event", authentification)
  # experiments_data <- mod_experiment_explorer_server("experiments_data", authentification, multiple = TRUE)
  # data <- mod_data_explorer_server("data", authentification, options = list(experiment = experiments_data$selected, page = 1))
  
}
