library(testthat)
library(clay)

test_check("clay")
